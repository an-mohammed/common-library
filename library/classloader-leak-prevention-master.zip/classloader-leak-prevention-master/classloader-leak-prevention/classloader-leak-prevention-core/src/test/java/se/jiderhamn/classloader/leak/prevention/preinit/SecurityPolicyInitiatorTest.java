package se.jiderhamn.classloader.leak.prevention.preinit;

import org.junit.Ignore;

/**
 * Test cases for {@link SecurityPolicyInitiator}
 * @author Mattias Jiderhamn
 */
@Ignore // Fixed in newer versions of Java?
public class SecurityPolicyInitiatorTest extends PreClassLoaderInitiatorTestBase<SecurityPolicyInitiator> {
}