package se.jiderhamn.classloader.leak.prevention.preinit;

import org.junit.Ignore;

/**
 * Test cases for {@link SecurityProvidersInitiator}
 * @author Mattias Jiderhamn
 */
@Ignore // Cannot be tested this way?
public class SecurityProvidersInitiatorTest extends PreClassLoaderInitiatorTestBase<SecurityProvidersInitiator> {
}