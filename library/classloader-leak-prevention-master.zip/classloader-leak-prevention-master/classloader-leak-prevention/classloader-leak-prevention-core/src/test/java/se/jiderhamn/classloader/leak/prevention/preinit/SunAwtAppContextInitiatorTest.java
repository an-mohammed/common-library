package se.jiderhamn.classloader.leak.prevention.preinit;

/**
 * Test cases for {@link SunAwtAppContextInitiator}
 * @author Mattias Jiderhamn
 */
public class SunAwtAppContextInitiatorTest extends PreClassLoaderInitiatorTestBase<SunAwtAppContextInitiator> {
}