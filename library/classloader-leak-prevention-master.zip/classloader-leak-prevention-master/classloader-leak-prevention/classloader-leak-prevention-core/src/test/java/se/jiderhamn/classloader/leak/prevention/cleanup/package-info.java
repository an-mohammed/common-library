package se.jiderhamn.classloader.leak.prevention.cleanup;

/**
 * Test cases in this package are used to confirm a) that a leak exists and b) that the 
 * {@link se.jiderhamn.classloader.leak.prevention.ClassLoaderPreMortemCleanUp} is able to circumvent the leak. */