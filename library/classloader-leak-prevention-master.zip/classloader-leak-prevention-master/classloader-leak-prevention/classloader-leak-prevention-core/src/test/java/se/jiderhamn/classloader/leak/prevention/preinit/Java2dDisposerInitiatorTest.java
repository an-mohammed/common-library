package se.jiderhamn.classloader.leak.prevention.preinit;

import org.junit.Ignore;

/**
 * Test cases for {@link Java2dDisposerInitiator}
 * @author Mattias Jiderhamn
 */
@Ignore // Fixed in newer versions of Java
public class Java2dDisposerInitiatorTest extends PreClassLoaderInitiatorTestBase<Java2dDisposerInitiator> {

}