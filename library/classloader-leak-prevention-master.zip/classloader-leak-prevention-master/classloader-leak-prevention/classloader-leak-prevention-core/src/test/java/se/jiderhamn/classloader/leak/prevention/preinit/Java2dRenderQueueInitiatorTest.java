package se.jiderhamn.classloader.leak.prevention.preinit;

/**
 * Test cases for {@link Java2dRenderQueueInitiator}
 */
public class Java2dRenderQueueInitiatorTest extends PreClassLoaderInitiatorTestBase<Java2dRenderQueueInitiator> {
}