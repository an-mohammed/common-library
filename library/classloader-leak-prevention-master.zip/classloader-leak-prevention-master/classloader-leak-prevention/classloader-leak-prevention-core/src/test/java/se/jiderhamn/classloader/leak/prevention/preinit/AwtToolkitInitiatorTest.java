package se.jiderhamn.classloader.leak.prevention.preinit;

import org.junit.Ignore;

/**
 * Test case for {@link AwtToolkitInitiator}
 * @author Mattias Jiderhamn
 */
@Ignore // Fixed in newer versions of Java?
public class AwtToolkitInitiatorTest extends PreClassLoaderInitiatorTestBase<AwtToolkitInitiator> {
}