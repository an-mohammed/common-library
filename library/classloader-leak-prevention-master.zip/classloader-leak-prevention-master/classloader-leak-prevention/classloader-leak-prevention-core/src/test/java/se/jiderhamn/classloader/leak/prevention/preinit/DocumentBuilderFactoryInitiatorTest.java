package se.jiderhamn.classloader.leak.prevention.preinit;

import org.junit.Ignore;

/**
 * Test cases for {@link DocumentBuilderFactoryInitiator}
 * @author Mattias Jiderhamn
 */
@Ignore // Fixed in newer versions of Java?
public class DocumentBuilderFactoryInitiatorTest extends PreClassLoaderInitiatorTestBase<DocumentBuilderFactoryInitiator> {
}