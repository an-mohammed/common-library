package se.jiderhamn.classloader.leak.prevention.preinit;

/**
 * Test cases for {@link SunGCInitiator}
 * @author Mattias Jiderhamn
 */
public class SunGCInitiatorTest extends PreClassLoaderInitiatorTestBase<SunGCInitiator> {
}