package se.jiderhamn.classloader;

/**
 * Class used to help identify leaked class loaders in a heap dump.
 * Inspired by Caucho's Resin
 * @author Mattias Jiderhamn
 */
public class ZombieMarker {
}