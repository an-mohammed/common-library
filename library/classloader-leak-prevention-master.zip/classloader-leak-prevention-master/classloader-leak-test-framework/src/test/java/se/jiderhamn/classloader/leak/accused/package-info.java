package se.jiderhamn.classloader.leak.accused;

/* Test cases in this package are used to confirm that code accused of causing leaks, does in fact <strong>not</strong> cause leaks */