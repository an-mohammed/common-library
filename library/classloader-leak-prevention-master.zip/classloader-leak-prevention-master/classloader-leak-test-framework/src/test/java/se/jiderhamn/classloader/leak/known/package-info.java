package se.jiderhamn.classloader.leak.known;

/** Test cases in this package are used to confirm the existence of known leaks */